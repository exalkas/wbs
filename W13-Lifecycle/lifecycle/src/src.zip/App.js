import ClassComponent from './ClassComponent'
import './App.css';

function App() {
  return (
    <div className="App">
      <ClassComponent />
    </div>
  );
}

export default App;
