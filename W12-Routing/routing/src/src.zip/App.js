// Routing = to route/drive
// React Router dom
// Hiding/showing components
// import { useState, useEffect } from 'react';
// install npm i react-router-dom
// https://reactrouter.com/web

import { BrowserRouter, Link, Route, Switch, Redirect, useParams } from 'react-router-dom';
import './App.css';
import Home from './components/Home/Home';
import MainLayout from './hoc/MainLayout';
import SimpleLayout from './hoc/SimpleLayout';



function App() {

  // const [something, setSomething]  = useState()

  // useEffect(async () => {
  //   await setSomething('Here I am')

  //   console.log(something)
  // }, [])

  // const showState = () => {
  //   setSomething('Here I am from menu')
  //   console.log(something)
  // }

  return (
    <div className="App">
      <BrowserRouter>

        <Switch>
          <Route path='/' exact>
            <MainLayout>
              <Route component={Home}/>
            </MainLayout>
          </Route>

          <Route path='/about' exact >
            <MainLayout>
                <Route component={About}/>
              </MainLayout>
          </Route>

          <Route path='/users' exact >
            <SimpleLayout>
                <Route component={Users}/>
            </SimpleLayout>
          </Route>
          <Route path='/user:id' exact component={User}>
            <SimpleLayout>
                <Route component={Users}/>
            </SimpleLayout>
          </Route>
          
          <Redirect from='/login' to='/users'/>
          
          <Route  exact component={NotFound}>
            <SimpleLayout>
                <Route component={Users}/>
            </SimpleLayout>
          </Route>
        </Switch>

      </BrowserRouter>
    </div>
  );
}

export default App;


function About() {
  return <h2>About</h2>
}
function Users() {
  const userId= '456'
  return <h2>Users for user click <Link to={`/user:${userId}`}>here</Link></h2>
}
function User() {
  const {id} = useParams()
  return <h2>Hello this is user {id}</h2>
}
function NotFound() {
  return <h2>Page Not Found</h2>
}
