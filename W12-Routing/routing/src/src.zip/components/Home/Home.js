import React from 'react'

export default function Home() {
    return <h2>Home</h2>
}